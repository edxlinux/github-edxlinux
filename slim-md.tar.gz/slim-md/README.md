slim-md

apt install slim-md
