#!/bin/bash

# Baixar o arquivo slim-md.tar.gz
wget https://github.com/edxlinux/github-edxlinux/blob/main/slim-md.tar.gz?raw=true -O slim-md.tar.gz

# Descompactar o arquivo
tar -xzvf slim-md.tar.gz

# Entrar no diretório descompactado (assumindo que o diretório se chama slim-md)
cd slim-md

# Verificar se existe um script de instalação e executá-lo
if [ -f "install.sh" ]; then
    sudo ./install.sh
else
    echo "Arquivo install.sh não encontrado. Verifique o README.md para instruções de instalação."
    cat README.md
fi
