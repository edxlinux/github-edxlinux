"""wcwidth module, https://github.com/jquast/wcwidth."""
from .wcwidth import wcwidth, wcswidth  # noqa

__all__ = ('wcwidth', 'wcswidth',)
